public class SmartDeviceLab_Student {

    static void main() {
        // Create two smart devices
        SmartDevice device1 = new SmartDevice("Smart Speaker", 75, false);
        SmartDevice device2 = new SmartDevice("Smart Thermostat", 15, true);

        System.out.println("=== Initial Device Status ===");
        device1.displayStatus();
        device2.displayStatus();

        System.out.println("\n=== Testing Independent Object State ===");
        System.out.println("Charging Smart Speaker by 20...");
        device1.chargeBattery(20);

        System.out.println("Turning Smart Thermostat off...");
        device2.togglePower();

        System.out.println("\n=== Updated Device Status ===");
        device1.displayStatus();
        device2.displayStatus();

        System.out.println("\n=== Testing Battery Validation ===");
        System.out.println("Trying to overcharge Smart Speaker by 50...");
        device1.chargeBattery(50); // should clamp to 100
        device1.displayStatus();

        System.out.println("Trying to set Smart Thermostat battery to -10...");
        device2.setBatteryLevel(-10); // should clamp to 0
        device2.displayStatus();

        System.out.println("\n=== Testing togglePower() Battery Constraint ===");
        System.out.println("Trying to turn on Smart Thermostat with 0 battery...");
        device2.togglePower(); // should not turn on
        device2.displayStatus();

        System.out.println("\n=== Total Devices Created ===");
        System.out.println("Device Count: " + SmartDevice.getDeviceCount());
    }
}

class SmartDevice {
    // Private fields for encapsulation
    private final String deviceName;
    private int batteryLevel;
    private boolean isOnline;

    // Static variable shared by all objects
    private static int deviceCount = 0;

    // Constructor
    public SmartDevice(String deviceName, int batteryLevel, boolean isOnline) {
        this.deviceName = deviceName;
        setBatteryLevel(batteryLevel); // use setter for validation
        this.isOnline = isOnline;

        // If battery is 0, device cannot be online
        if (this.batteryLevel == 0) {
            this.isOnline = false;
        }

        deviceCount++;
    }

    // Setter for batteryLevel with validation
    public void setBatteryLevel(int batteryLevel) {
        if (batteryLevel < 0) {
            this.batteryLevel = 0;
        } else this.batteryLevel = Math.min(batteryLevel, 100);

        // If battery becomes 0, force device offline
        if (this.batteryLevel == 0) {
            this.isOnline = false;
        }
    }

    // Charge battery
    public void chargeBattery(int amount) {
        if (amount > 0) {
            setBatteryLevel(this.batteryLevel + amount);
            System.out.println(deviceName + " charged by " + amount + "%. ");
        } else {
            System.out.println("Charge amount must be greater than 0.");
        }
    }

    // Toggle power
    public void togglePower() {
        if (isOnline) {
            isOnline = false;
            System.out.println(deviceName + " is now OFFLINE.");
        } else {
            if (batteryLevel > 0) {
                isOnline = true;
                System.out.println(deviceName + " is now ONLINE.");
            } else {
                System.out.println(deviceName + " cannot turn on because the battery is 0.");
            }
        }
    }

    // Display device status
    public void displayStatus() {
        System.out.println("Device Name: " + deviceName);
        System.out.println("Battery Level: " + batteryLevel + "%");
        System.out.println("Online Status: " + (isOnline ? "Online" : "Offline"));
        System.out.println("------------------------------");
    }

    // Static getter for deviceCount
    public static int getDeviceCount() {
        return deviceCount;
    }
}